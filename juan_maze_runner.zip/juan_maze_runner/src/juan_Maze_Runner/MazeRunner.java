package juan_Maze_Runner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MazeRunner {
	
	private char[][] mazeArray; //create the array to build the maze.
	private int startCol, startRow; //start coordinates (denotated by 'S' in the maze)
	private int mazeRows, mazeCols; //rows and cols of the maze
	private String outputFilenameConsole; // you can pass the output filename from the main method here.
	
	public MazeRunner(String filename) throws IOException {
		
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			fileName(filename);
			mazeBuilder(reader); //build the maze using the filename as an input.
			reader.close();
			startSpot(mazeRows, mazeCols); // seek for the start position 'S'
			if (mazeSolver(this.startRow, this.startCol)){
				System.out.println("The maze has been Solved! Congratz!"); 
			} else {
				System.out.println("The maze has no way out!!"); 
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Error : " + e.getMessage());
		}
	}

	private void mazeBuilder(BufferedReader reader) throws IOException {
		StringBuilder stringBuilder = new StringBuilder();
		String line = "";
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
			this.mazeRows++;
		}
		String lines = stringBuilder.toString();
		this.mazeCols = lines.length() / this.mazeRows;
		this.mazeArray = new char[this.mazeRows][this.mazeCols];
		int maze = 0;
		System.out.println();
		for (int i = 0; i < this.mazeRows; i++) {
			for (int j = 0; j < this.mazeCols; j++) {
				this.mazeArray[i][j] = stringBuilder.charAt(maze++);
			}
		}
	}
	
	private BufferedReader fileName(String filename) throws FileNotFoundException {
		this.outputFilenameConsole = filename;
		BufferedReader buffer = new BufferedReader(new FileReader(filename));
		return buffer;
	}


	private void startSpot(int rows, int cols) {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (mazeArray[i][j] == 'S') {
					this.startRow = i;
					this.startCol = j;
				}
			}
		}
	}

	/**
	 * 
	 * mazeSolver description : 
     * mazeSolver use BackTracking to reach the point 'E' to solve the Maze.
	 * The Maze fills the path with 'X' in an output file. The Maze goes from 'S' filling the path with 'X' and reaching the end point 'E'.
	 * if the path is not valid , the solution will be false, than we will search the other trees  trying to reach the path ('E' spot).
	 */
	private boolean mazeSolver(int row, int col) {
		
		char moveEast  = this.mazeArray[row][col + 1];
		char moveWest  = this.mazeArray[row][col - 1];
		char moveNorth = this.mazeArray[row - 1][col];
		char moveSouth = this.mazeArray[row + 1][col];
		
		if (moveEast == 'E' || moveWest == 'E' || moveNorth == 'E' || moveSouth == 'E') {
			this.mazeArray[row][col] = 'X'; 
			try {
				solutionOutPut();
			} catch (FileNotFoundException e) {
				System.out.println("ERROR : " + e.getMessage());
			}
			return true;
		}
		
		boolean solved = false;
		if (this.mazeArray[row][col] != 'S') {
			this.mazeArray[row][col] = 'X';
		}
		if (moveEast == ' ' && !solved) { 			
			solved = mazeSolver(row , col + 1);		
		}										
		if (moveSouth == ' ' && !solved) {			
			solved = mazeSolver(row + 1, col);		
		}										
		if (moveWest == ' ' && !solved) {			
			solved = mazeSolver(row, col - 1);		
		}										
		if (moveNorth == ' ' && !solved) {
			solved = mazeSolver(row - 1, col);
		}
		if (!solved) {
			this.mazeArray[row][col] = ' ';	//maze has no way out.
		} 
		
		return solved;
								 
	}			

	
	// creating an output file with the Maze Solution
	private void solutionOutPut() throws FileNotFoundException {
		File file = new File(this.outputFilenameConsole+" mazeSolution"); 
																	
		PrintWriter writer = new PrintWriter(file);
		for (int i = 0; i < this.mazeRows; i++) {
			for (int j = 0; j < this.mazeCols; j++) {
				writer.print(this.mazeArray[i][j]);
			}
			writer.println();
		}
		writer.close();
	}
}
