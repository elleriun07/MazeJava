package juan_Maze_Runner;

public class Coordinates {

	private static int row;
	private static int col;
	
	public Coordinates(int row, int coll){
		
		this.row = row;
		this.col = coll;
		
	}

   public int getRow(){
	   
	   return row;
   }
   
   public int getCol(){
	   
	   return col;
   }
	
}
