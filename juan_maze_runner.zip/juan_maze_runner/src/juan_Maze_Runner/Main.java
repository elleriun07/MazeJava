package juan_Maze_Runner;

import java.io.IOException;

/**
 * Description:
 * This class creates a new Maze passing the file name as a command line argument or by passing the file name itself.
 * It calls solve(int row, in col)
 * Thanks for the opportunity and the fun task, i made an maze during my university too and a Tetris as well, i enjoy making these "games".
 */
public class Main {
	
	public static void main(String[] args) throws IOException{
		try {
			new MazeRunner("large_input.txt"); //pass the .txt file here to create a mazeSolution.
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
